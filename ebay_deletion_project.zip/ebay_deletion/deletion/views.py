import os
import json
import base64
import hashlib
import requests
import logging
from OpenSSL import crypto
from rest_framework import status
from rest_framework.views import APIView
from django.http import JsonResponse

logger = logging.getLogger(__name__)

class EbayMarketplaceAccountDeletion(APIView):
    CHALLENGE_CODE = 'challenge_code'
    VERIFICATION_TOKEN = os.environ.get('VERIFICATION_TOKEN')
    ENDPOINT = 'https://example.com/ebay_marketplace_account_deletion'
    X_EBAY_SIGNATURE = 'X-Ebay-Signature'
    EBAY_BASE64_AUTHORIZATION_TOKEN = os.environ.get('EBAY_BASE64_AUTHORIZATION_TOKEN')

    def get(self, request):
        challenge_code = request.GET.get(self.CHALLENGE_CODE)
        challenge_response = hashlib.sha256(challenge_code.encode('utf-8') +
                                            self.VERIFICATION_TOKEN.encode('utf-8') +
                                            self.ENDPOINT.encode('utf-8'))
        return JsonResponse({"challengeResponse": challenge_response.hexdigest()}, status=status.HTTP_200_OK)

    def post(self, request):
        x_ebay_signature = request.headers[self.X_EBAY_SIGNATURE]
        x_ebay_signature_decoded = json.loads(base64.b64decode(x_ebay_signature).decode('utf-8'))
        kid = x_ebay_signature_decoded['kid']
        signature = x_ebay_signature_decoded['signature']

        public_key = None
        try:
            ebay_verification_url = f'https://api.ebay.com/commerce/notification/v1/public_key/{kid}'
            oauth_access_token = self.get_oauth_token()
            headers = {'Authorization': f'Bearer {oauth_access_token}'}
            r = requests.get(url=ebay_verification_url, headers=headers)
            if r.status_code == 200:
                public_key = r.json()['key']
        except Exception as e:
            logger.error(f"Get Public Key Error: {e}")
            return JsonResponse({}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        pkey = crypto.load_publickey(crypto.FILETYPE_PEM, self.get_public_key_into_proper_format(public_key))
        cert = crypto.X509(); cert.set_pubkey(pkey)
        try:
            crypto.verify(cert, base64.b64decode(signature), request.body, 'sha1')
        except Exception as e:
            logger.warning(f"Signature Invalid: {e}")
            return JsonResponse({}, status=status.HTTP_412_PRECONDITION_FAILED)

        return JsonResponse({}, status=status.HTTP_200_OK)

    def get_oauth_token(self):
        url = 'https://api.ebay.com/identity/v1/oauth2/token'
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': f"Basic {self.EBAY_BASE64_AUTHORIZATION_TOKEN}"
        }
        payload = 'grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope'
        r = requests.post(url, headers=headers, data=payload)
        return r.json()['access_token']

    @staticmethod
    def get_public_key_into_proper_format(public_key):
        return public_key[:26] + '\n' + public_key[26:-24] + '\n' + public_key[-24:]
