from django.urls import path
from deletion.views import EbayMarketplaceAccountDeletion

urlpatterns = [
    path('ebay_marketplace_account_deletion', EbayMarketplaceAccountDeletion.as_view(), name='ebay_deletion'),
]
