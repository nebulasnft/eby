import os

SECRET_KEY = 'django-insecure-temp-key'
DEBUG = True
ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.contenttypes',
    'django.contrib.staticfiles',
    'deletion',
]

MIDDLEWARE = [
    'django.middleware.common.CommonMiddleware',
]

ROOT_URLCONF = 'ebay_deletion.urls'

TEMPLATES = []
WSGI_APPLICATION = 'ebay_deletion.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR := os.path.dirname(os.path.dirname(__file__)), 'db.sqlite3'),
    }
}

STATIC_URL = '/static/'
